import React, { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { NavLink, useNavigate } from 'react-router-dom';
import axios from 'axios';




function Signup() {

  const [name, setName] = useState('');
  const [email , setEmail] = useState('')
  const [phone, setPhone] = useState('');
  const [work, setWork] = useState('');
  const [password , setPassword] = useState('');
  const [cpassword , setCpassword] = useState('');
  const navigate = useNavigate();



  // function for register to connect with backend
  const handleRegister = (event) => {
   
    event.preventDefault();
    // jo backend se data aayega usko rakhega wo

    axios.post('http://localhost:5000/register', { name, email, phone, work, password, cpassword })
      .then(res => {
        if (res.data.success === false) {
          alert(res.data.msg);
        }
        else {
          alert("Signup successfully")
          console.log(res)
          navigate("/login")
        }
      })
      .catch(err => console.log(err));



  }


  return (
    <>
      <section className="h-100 bg-dark">
        <div className="container py-5 h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col">
              <div className="card card-registration my-4">
                <div className="row g-0">
                  <div className="col-xl-6 d-none d-xl-block">
                    <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img4.webp"
                      alt="Sample" className="img-fluid"
                      style={{ borderTopLeftRadius: " .25rem", borderBottomLeftRadius: ".25rem;" }} />
                  </div>

                  <form onSubmit={handleRegister} className="col-xl-6">
                    <div className="card-body p-md-5 text-black">
                      <h3 className="mb-5 text-uppercase">User registration form</h3>

                      <div className="row">


                        <div className="form-outline mb-4">
                          <input 
                            name="name" onChange={e => setName(e.target.value)} type="text" id="form3Example1n" className="form-control form-control-lg" />
                          <label className="form-label" for="form3Example1n">Your name</label>
                        </div>
                      </div>


                      <div className="form-outline mb-4">
                        <input name="email" style={{ textTransform: "lowercase" }} onChange={e=> setEmail(e.target.value)}
                          type="text" id="form3Example97" className="form-control form-control-lg" />
                        <label className="form-label" for="form3Example97">Email ID</label>
                      </div>
                      <div className="form-outline mb-4">
                        <div className="form-outline">
                          <input  name="phone" onChange={e=> setPhone(e.target.value)}
                            type="number" id="form3Example1m1" className="form-control form-control-lg" />
                          <label className="form-label" for="form3Example1m1"> Phone Number</label>
                        </div>
                      </div>

                      <div className="form-outline mb-4">
                        <div className="form-outline">
                          <input name="work" onChange={e=> setWork(e.target.value)}
                            type="text" id="form3Example1m1" className="form-control form-control-lg" />
                          <label className="form-label" for="form3Example1m1">work</label>
                        </div>
                      </div>

                      <div className="form-outline mb-4">
                        <div className="form-outline">
                          <input  name="password" onChange={e=> setPassword(e.target.value)}
                            type="password" id="form3Example1n1" className="form-control form-control-lg" />
                          <label className="form-label" for="form3Example1n1">password</label>
                        </div>
                      </div>
                      <div className="form-outline mb-4">
                        <div className="form-outline">
                          <input  name="cpassword" onChange={e=> setCpassword(e.target.value)}
                            type="password" id="form3Example1n1" className="form-control form-control-lg" />
                          <label className="form-label" for="form3Example1n1">confirm password</label>
                        </div>
                      </div>

                      <div className="d-flex justify-content-end pt-3">

                        <button type="submit" value="register"  className="btn btn-warning btn-lg ms-2">Registration</button>
                        <NavLink to="/login" className="btn btn-light btn-lg">Login</NavLink>
                        {/* <button type="button" className="btn btn-light btn-lg">Login</button> */}

                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Signup