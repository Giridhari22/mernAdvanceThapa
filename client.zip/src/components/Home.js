import React from 'react'
import './Home.css'


const Home=() =>{
  return (
    <div>
      <section id="Home">
        <div className="Home-main">
          <div className="containers">
          <h1 className="display-4">Welcome to my website!</h1>
          <p className="lead">I'm a MERN stack developer</p>
          <hr className="my-2"/>
            
            <a className="btn btn-primary btn-lg" href="/contact" role="button">Get in touch</a>
          </div>
        </div>
      </section>
      
    </div>
  )
}

export default Home