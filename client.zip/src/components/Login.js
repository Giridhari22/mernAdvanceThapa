import React, { useState } from 'react';
import {
  MDBBtn,
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBRow,
  MDBCol,
  MDBIcon,
  MDBInput
}
  from 'mdb-react-ui-kit';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

// import "./Login.css"

function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const navigate = useNavigate();


  const handleLogin = () => {
    axios.post("http://localhost:5000/signin", { email, password })
      .then(res => {
        console.log(res.data)
        if (res.data.success === false) {
          window.alert('invalid credentials')
          alert(res.data.msg);
        }
        else {
          // localStorage.setItem("token", res.data.token)
          // localStorage.setItem("user", JSON.stringify(res.data.user))
          navigate("/About")
          alert("Congratulation you loged in successfully")
        }
      })
      .catch(err => console.log(err));
  }

  return (
    <MDBContainer className="my-5 " >

      <MDBCard>
        <MDBRow className='g-0'>

          <MDBCol md='6'>
            <MDBCardImage src='https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/img1.webp' alt="login form" className='rounded-start w-100' />
          </MDBCol>

          <MDBCol md='6'>
            <MDBCardBody className='d-flex flex-column'>

              {/* <div className='d-flex flex-row mt-2'>
                <MDBIcon fas icon="cubes fa-3x me-3" style={{ color: '#ff6219' }} />
                
              </div> */}

              <h5 className="fw-normal my-4 pb-3" style={{ letterSpacing: '1px' }}>Sign into your account</h5>

              <MDBInput wrapperClass='mb-4' value={email} onChange={e => setEmail(e.target.value)} label='Email address' id='formControlLg' type='email' style={{ textTransform: "lowercase" }} size="lg" />
              <MDBInput wrapperClass='mb-4' value={password} onChange={e => setPassword(e.target.value)} label='Password' id='formControlLg' type='password' size="lg" />

              <button type="submit" onClick={handleLogin} value="login" className="btn btn-warning btn-lg ms-2">Login</button>
              {/* <MDBBtn className="mb-4 px-5" color='dark' size='md'>Login</MDBBtn> */}
              <a className="small text-muted" href="#!">Forgot password?</a>
              <p className="mb-5 pb-lg-2" style={{ color: '#393f81' }}>Don't have an account? <a href="/signup" style={{ color: '#393f81' }}>Register here</a></p>



            </MDBCardBody>
          </MDBCol>

        </MDBRow>
      </MDBCard>

    </MDBContainer>
  );
}

export default Login;