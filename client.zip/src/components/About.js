import React,{useEffect, useState} from 'react'

import 'bootstrap/dist/css/bootstrap.min.css';
import { NavLink } from 'react-router-dom';
import './About.css'
import {useNavigate} from 'react-router-dom';
import axios from 'axios';


function About() {
  const navigate = useNavigate([]);
  const [userData, setUserData] = useState();
// 21. ab about wale router ko get karna hai aur check v krna h ki user authenticated hai ya nahi
const callAboutPage = async() =>{
  try {
    // const res = await fetch('/about',{
    //   method :"GET",
    //   headers:{
    //     Accept:"application/json",
    //     "Content -Type":"application/json"
    //   },
    //   // cookie ko backend tak pahuchane k liye
    //   credentials:"include"
    // }); 

    // const data = await res.json();
    // console.log(data);
    // setUserData(data);
   

    // if(!res.status ===200){
    //   const error = new Error(res.error);
    //   throw error ;
    // }
    const res = await axios.get('http://localhost:5000/about' , {
      headers:{
        Accept: "application/json",
        // "Content -Type":"application/json",
        Authorization: localStorage.getItem("token")
      }
    })
    console.log(res)
  } catch (error) {
    console.log(error);
    navigate('/login');
  }
}

// 20 ek function likhnge jo page start hone pe hi dikh jata hai
  //  useEffect(()=>{
  //     callAboutPage()
  //  },[])

  return (
    <>
      <section className="h-100 bg-dark">
        <div className="container py-5 h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col">
              <div className="card card-registration my-4">
                <div className="row g-0">
                  <div className="col-xl-2 d-none d-xl-block">
                    <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img4.webp"
                      alt="Sample photo" className="img-fluid"
                      style={{ borderTopLeftRadius: " .25rem", borderBottomLeftRadius: ".25rem;" }} />
                    <div className=' col-xl-14 d-none d-xl-block '>
                     <div>
                        <a href="https://www.youtube.com/@giridharijha8599">Youtube</a>
                      <br />
                        <a href="https://www.instagram.com/giridhari_j_h_a/">Instagram</a>
                      <br />
                        <a href="https://github.com/Giridhari22">Github</a>
                      <br />
                      <a href="">Portfolio</a>
                      <br />
                      <a href="">Web Developer</a>
                     
                      </div>
                    </div>

                  </div>

                  <form method='GET' className="col-xl-10">
                    <div className="card-body p-md-5 text-black">
                      <div className="row">
                          <div>

                        <h2>About Us Page</h2>
                          </div>
                          <hr />
                        
                        {/*  */}
                        <div className="col-md-6 mb-4">
                          <div>
                            <h1>Giridhari Jha</h1>
                            <h6>Web Developer</h6>
                          </div>

                        </div>
                        <div className="col-md-6 mb-6">
                          <input type="submit" className='profile-edit-btn' name='btnAddMore' value='Edit Profile' />
                        </div>
                        <hr />
                        {/*  */}
                        {/*User Id  */}
                        <div className="col-md-6 mb-4">

                          <div className="form-outline">
                            {/* <input type="text" id="form3Example1m" className="form-control form-control-lg" /> */}
                            {/* <label className="form-label" for="form3Example1m">UserId:   <h6>89739759752</h6></label> */}
                            <h3>User Id:</h3>
                          </div>
                        </div>
                        <div className="col-md-6 mb-4">
                          <div className="form-outline">
                           
                            <h6 >8947697496794</h6>
                          </div>
                        </div>

                   
                      {/* Name */}
                      <div className="col-md-6 mb-4">

                        <div className="form-outline">
                          {/* <input type="text" id="form3Example1m" className="form-control form-control-lg" /> */}
                          {/* <label className="form-label" for="form3Example1m">UserId:   <h6>89739759752</h6></label> */}
                          <h3>Name</h3>
                        </div>
                      </div>

                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          {/* <input type="text" id="form3Example1n" className="form-control form-control-lg" /> */}
                          {/* <label className="form-label" for="form3Example1n">Last name</label> */}
                          <h6>Giridhari Jha</h6>
                        </div>
                      </div>
                   
                    {/* Email */}
                    <div className="col-md-6 mb-4">

                      <div className="form-outline">
                        {/* <input type="text" id="form3Example1m" className="form-control form-control-lg" /> */}
                        {/* <label className="form-label" for="form3Example1m">UserId:   <h6>89739759752</h6></label> */}
                        <h3>Email</h3>
                      </div>
                    </div>
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        {/* <input type="text" id="form3Example1n" className="form-control form-control-lg" /> */}
                        {/* <label className="form-label" for="form3Example1n">Last name</label> */}
                        <h6>giridharijha123@gmail.com</h6>
                      </div>
                    </div>
                
                {/* Phone */}
                <div className="col-md-6 mb-4">

                  <div className="form-outline">
                    {/* <input type="text" id="form3Example1m" className="form-control form-control-lg" /> */}
                    {/* <label className="form-label" for="form3Example1m">UserId:   <h6>89739759752</h6></label> */}
                    <h3>Phone</h3>
                  </div>
                </div>
                <div className="col-md-6 mb-4">
                  <div className="form-outline">
                    {/* <input type="text" id="form3Example1n" className="form-control form-control-lg" /> */}
                    {/* <label className="form-label" for="form3Example1n">Last name</label> */}
                    <h6>9060294734</h6>
                  </div>
                </div>
             
              {/* Profession */}
              <div className="col-md-6 mb-4">

                <div className="form-outline">
                  {/* <input type="text" id="form3Example1m" className="form-control form-control-lg" /> */}
                  {/* <label className="form-label" for="form3Example1m">UserId:   <h6>89739759752</h6></label> */}
                  <h3>Profession</h3>
                </div>
              </div>
              <div className="col-md-6 mb-4">
                <div className="form-outline">
                  {/* <input type="text" id="form3Example1n" className="form-control form-control-lg" /> */}
                  {/* <label className="form-label" for="form3Example1n">Last name</label> */}
                  <h6>MERN STACK Developer</h6>
                </div>
              </div>
           

          </div>
        </div>

      </form>
    </div >
              </div >
            </div >
          </div >
        </div >
      </section >
    </>
  )
}

export default About