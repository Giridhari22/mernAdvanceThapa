import React from 'react';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css';
import { NavLink } from 'react-router-dom';
// import NavDropdown from 'react-bootstrap/NavDropdown';
// import { useNavigate } from 'react-router-dom';
// import './Navbar.css';


function NavbarElem() {
    // const navigate = useNavigate();
   

    // const handleLogout = () => {
    //     localStorage.clear();
    //     navigate("/")
    // }


    return (
        <Navbar className="navbar navbar-light " expand="lg"  >
            <Container>
                <Navbar.Brand href="#home">Giridhari<span style={{ color: "orange", fontFamily: 'Roboto Slab' }}>jha</span></Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="ms-auto navbar-nav navbar-right">
                        <Nav.Link href="/">Home</Nav.Link>
                        <Nav.Link href="/Contact">Contact Us</Nav.Link>
                        <Nav.Link href="/About">About Me</Nav.Link>
                        <Nav.Link href="/Login">Login</Nav.Link>
                        <Nav.Link href="/Signup">Register</Nav.Link>



                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
}

export default NavbarElem;