import {  Route , Routes } from 'react-router-dom';
import './App.css';
import Home from './components/Home';
import NavbarElem from './components/Navbar'
import Contact from './components/Contact'
import About from './components/About'
import Login from './components/Login'
import Signup from './components/Signup'
import NotFoundPage from './components/404Error';


function App() {
  return (
    <div className="App">
      <NavbarElem />

     <Routes>

      <Route exact path="/" element={<Home />} />

      <Route path="/About" element={<About />} />
        

      <Route path="/contact" element={<Contact />} />
        
      

      <Route path="/login" element={<Login />} />
        
      

      <Route path="/signup" element={<Signup />} />
        <Route path="/NotFoundPage" element={< NotFoundPage />} />

        

        
      
      </Routes>
     
    </div>
  );
}

export default App;
