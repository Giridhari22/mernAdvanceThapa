
const dotenv = require("dotenv")
const express = require("express");
const jwt = require("jsonwebtoken");

const app = express();
const cors = require('cors');
const cookieParser = require('cookie-parser')
// 4. connecting to env file to secure url
// ek  bar agr dotenv ka path yaha set kar diya to ab khi v krne ki jrrurat nhi h
dotenv.config({path:'./config.env'})
const PORT = process.env.PORT;

// 5. database wale file ko bas require karna hai
require('./db/conn');

// ham kya kr rhe ki jo v data aayega n hamesa usko object m chnge kr denge
app.use(express.json());
app.use(cors())
app.use(cookieParser())

// 8.models require karna jo userschema bana hua hai
const User = require('./models/userSchema');
 
// 9.router file ko set krna hai
app.use(require('./Router/auth'))

// 2. Middlewares
// middlewares fn are functions that have access to the req object , the res obj , and the next fn in the application request-response cycle .

// the next function is a function in the express router which , when invoked , executes the middleware succeedding the current middleware. 
 


// 1. router and connection



// app.get('/about', (req, res) => {
//     console.log("hello for middleware")
//     res.send("Hello  from the about")
// })

app.get('/contact', (req, res) => {
    res.cookie("jwtoken", 'Giridhari')
    res.send("Hello  from the contact")
})

app.get('/signin', (req, res) => {
    res.send("Hello  from the signin")
})
app.get('/signup', (req, res) => {
    res.send("Hello  from the signup")
})

app.get('/logout', (req, res) => {
    res.send("Hello  from the logout")
})

app.listen(PORT, "127.0.0.1" ,()=>{
    console.log(`listening to port ${PORT}`)
})