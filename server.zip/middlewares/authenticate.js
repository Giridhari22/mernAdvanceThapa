 const jwt  = require("jsonwebtoken");
 const User = require("../models/userSchema");
// 19. hame user ko authenticate karwa k hi about page pe pahuchana hai
 const Authenticate = async(req,res, next)=>{
    try {
        const token = req.cookies.jwtoken;
        const verifyToken = jwt.verify(token, 'ILOVEYOUTRIPTIPATHAKANDIWANTTOHUGYOUASAGOODBOYFRIEND')
        console.log(verifyToken)
        const rootUser = await User.findOne({_id: verifyToken._id , "tokens.token":token});

        if(!rootUser){
            throw new Error('User not Found')}

            req.token = token;
            req.rootUser = rootUser;
            req.userID =  rootUser._id;
            next();

    } catch (error) {
        res.status(401).send("unauthorized : No token Provided");
        console.log(error)
    }
 }
// iske bade cookie-parser npm se download karna hai , taki token cookie se utha paye
 module.exports = Authenticate;