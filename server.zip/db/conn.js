const mongoose = require("mongoose")
// to use the link pasted in env fi
const DB = process.env.DATABASE

// 3. database connection
// return promise (either resolve or reject ) so we use then and catch
mongoose.connect(DB, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log("connection successful "))
    // for throwing error 
    .catch((err) => console.log(err));

