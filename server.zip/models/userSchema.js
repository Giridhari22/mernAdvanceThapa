// 6. user ka schema banana hai kaise kya create hoga
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");

// const bcrypt = require('bcryptjs')
const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    phone: {
        type: Number,
        required: true
    },
    work: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    cpassword: {
        type: String,
        required: true
    },
    // 18.TOKEN KO STORED KARWANA HAI
    tokens:[
        {
            token:{
                type: String,
                required: true
            }
        }
    ]

})

// 17. generating token
userSchema.methods.generateAuthToken = async function(){
    try {
        //  jwt.sign(payload(under obj format ), secretOrPrivateKey , [options, callback])
        let tokenGiri = jwt.sign({_id:this._id} , process.env.SECRET_KEY);
        // token m token ko stored karwaenge
        this.tokens = this.tokens.concat({token:tokenGiri });
        await this.save();
        return tokenGiri;
    } catch (error) {
        console.log(error)
    }
}

// 7. models bana na hai on the basis of schema
// hamesa first letter capital -User
//                          (collection name , schema name)
const User = mongoose.model('USER', userSchema)
// hamesa export kar denge taki dusre file m iska use ho paye
module.exports = User;
