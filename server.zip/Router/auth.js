const express = require('express');
const router = express.Router();
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const authenticate = require("../middlewares/authenticate");


// 12. database connection taki user ka data database pe ja sake
require("../db/conn")
const User = require("../models/userSchema");

router.get('/', (req, res) => {
    res.send('hi i m from auth side')
})
// 10. register k liye route
router.post("/register", async (req, res) => {
    // body se request kr rhe ye name
    const { name, email, phone, work, password, cpassword } = req.body;
    // 11.validation 
    if (!name || !email || !phone || !work || !password || !cpassword) {
        return res.status(422).json({ error: "plz fill the input box" })
    }
    // 13. database m check krna email registered hai ya nahi
    try {
        const userExist = await User.findOne({ email: email })
        const salt = await bcrypt.genSalt(10);

        if (userExist) {
            return res.status(422).json({ error: "Email already registered" })
        } else if (password != cpassword) {
            return res.status(422).json({ error: "password are not matching" })
        } else {

            const user = new User({
                name,
                email,
                phone,
                work,
                // 15 .hashing the password by using salt
                password: await bcrypt.hash(req.body.password, salt),
                cpassword: await bcrypt.hash(req.body.cpassword, salt)
            })

            await user.save();

            res.status(201).json({ message: "user registered successfully" });

        }

    } catch (error) {
        console.log(error);
    }
});

// 14.Login route
router.post('/signin', async (req, res) => {
    try {
        let token;
        // body se email aur password request krnge
        const { email, password } = req.body
        // email and password shouldn't be empty
        if (!email || !password) {
            return res.status(400).json({ error: "plz filled the data" })
        }

        const userLogin = await User.findOne({ email: email });
        if (userLogin) {
            // 16. to compare with by bcrypt that is this password is coorect or not
            const password_valid = await bcrypt.compare(password, userLogin.password);

            // 17. to create token so that when user get signin than we send a unique token 
            const token = await userLogin.generateAuthToken();
            console.log(token)

            // 18. we gonna store the token which is generated in the form of cookies
           res.cookie("jwtoken", token,{
                expires:new Date(Date.now()+ 25892000000),
                httpOnly:true //taki har jagah chle
            });
            //  validation
            if (!password_valid) {
                return res.status(200).json({success:false, error: "user not founds" })
               
            } else {
                return res.status(200).json({ success: true, message: "user signin successfully" })
            }
        } else {
            return res.status(400).json({ success: false, error: "invalid credentials" })

        }


    } catch (error) {
        console.log(error)
    }
})


// // About us page
// router.get('/about',authenticate, (req, res) => {
//     console.log("hello for middleware")
//     res.send(req.rootUser)
// })


module.exports = router;
